This package contains third-party software components governed by the license(s) indicated below:

Component Name: Draco 3D data compression library
License Type: "Apache License 2.0"
[Draco 3D data compression library License](https://github.com/google/draco/blob/master/LICENSE)
